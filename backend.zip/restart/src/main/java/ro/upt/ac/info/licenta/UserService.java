package ro.upt.ac.info.licenta;
public interface UserService {
    String login(String email, String parola);
}
