package ro.upt.ac.info.licenta;

public class Cerere {
    private String email;
    private String motiv;
    private String mentiuni;

    public String getEmail(){
        return this.email;
    }

    public String getMotiv(){
        return this.motiv;
    }

    public String getMentiuni(){
        return this.mentiuni;
    }

}
