package ro.upt.ac.info.licenta;

public class LoginInfo {
    private String email;
    private String parola;

    public String getEmail() {
        return email;
    }

    public String getParola() {
        return parola;
    }
}
