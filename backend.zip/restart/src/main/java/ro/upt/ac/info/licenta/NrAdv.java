package ro.upt.ac.info.licenta;

public class NrAdv {
    private String id;

    public String getId() {
        return id;
    }
}
